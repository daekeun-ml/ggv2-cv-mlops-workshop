install_libraries_darwin() {
    install_brew_darwin
    install_cmake_darwin
    install_gcc_darwin
}
install_cmake_darwin() {
    if [ -z "$(cmake --version)" ]; then
        echo "Installing cmake..."
        brew install cmake
    fi
}
install_gcc_darwin() {
    if [ -z "$(gcc --version)" ]; then
        echo "Installing gcc@8..."
        brew install gcc@8
    fi
}
install_brew_darwin() {
    if [ -z "$(brew --version)" ]; then
        echo "Installing brew..."
        curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh
        export PATH="/usr/local/opt/python/libexec/bin:$PATH"
    fi
}

get_macOS_verion() {
    major="$(cut -d'.' -f 1 <<<$@)"
    minor="$(cut -d'.' -f 2 <<<$@)"
    echo "$major""$minor"
}
get_macOS_tf_whl() {
    major="$(cut -d'.' -f 1 <<<$@)"
    minor="$(cut -d'.' -f 2 <<<$@)"
    echo "macosx_"$major"_"$minor"_"$machine".whl"
}

check_macOS_version_for_tf() {
    macOS_version=$(sw_vers -productVersion)
    get_macOS_verion_for_tf=$(get_macOS_verion "$macOS_version")
    valid_macOS_version_for_tf=["1015"]
    if [[ " ${valid_macOS_version_for_tf[*]} " == *"$get_macOS_verion_for_tf"* ]]; then
        echo "pip wheel of TensorFlow Lite exists for this macOS version:  "$macOS_version
        macOS_tf_whl=$(get_macOS_tf_whl "$macOS_version")
    else
        echo "pip wheel of TensorFlow Lite doesn't exist for this macOS version "$macOS_version
        exit 1
    fi

}
