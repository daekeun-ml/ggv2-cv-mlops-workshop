#!/bin/bash
. $(dirname "$0")/utils.sh
. $(dirname "$0")/virtual_env.sh

set -eux

# Get the parameters
while getopts ":p:e:" opt; do
    case $opt in
    p)
        ml_root_path="$OPTARG"
        ;;
    e)
        environment_file="$OPTARG"
        ;;
    \?)
        echo "Invalid option -$OPTARG" >&2
        ;;
    esac
done

# Validate the input params
if [[ -z "$ml_root_path" ]]; then
    echo "ML root path cannot be null or empty."
    exit 1
fi

kernel=$(uname -s)
tf_version="2.5.0"
min_py_version="3.0.0"
min_kernel_version="4.9.9"
min_pip_version="20.2.4"
machine=$(uname -m)
python_version=$(echo $(python3 --version) | cut -d' ' -f 2)
pip3_version=$(echo $(pip3 --version) | cut -d' ' -f 2)

# Supported tflite wheels for different devices based on the tflite version, python version and os version can be found at
# https://github.com/google-coral/pycoral/releases
tf_lite_link="https://github.com/google-coral/pycoral/releases/download/v1.0.1/"

case "$kernel" in
"Linux")
    target_platform_whl="$(echo $kernel | awk '{print tolower($0)}')_$machine"".whl"
    if check_tf "$machine"; then
        echo "Skipping TensorFlow installation as it already exists."
    else
        if is_debian; then
            . $(dirname "$0")/debian_installer.sh
            sudo apt install wget -y
            if [[ "$machine" == "x86_64" ]]; then
                echo "Installing Miniconda and creating virtual environment..."
                install_conda_x86_64 "$environment_file"
                echo "Installing awsiotsdk..."
                pip3 install awsiotsdk
                echo "Installing TensorFlow..."
                check_py_version_for_tf
                pip3 install $tf_lite_link"tflite_runtime-"$tf_version"-cp"$tf_compiled_py_version"-cp"$tf_compiled_py_version"m-"$target_platform_whl
            elif [[ "$machine" == "armv7l" ]]; then
                install_libraries_debian "$machine"
                echo "Installing TensorFlow..."
                check_py_version_for_tf
                pip3 install $tf_lite_link"tflite_runtime-"$tf_version"-cp"$tf_compiled_py_version"-cp"$tf_compiled_py_version"m-"$target_platform_whl
            elif [[ "$machine" == "aarch64" ]]; then
                install_libraries_debian "$machine"
                echo "Installing TensorFlow..."
                check_py_version_for_tf
                pip3 install $tf_lite_link"tflite_runtime-"$tf_version"-cp"$tf_compiled_py_version"-cp"$tf_compiled_py_version"m-"$target_platform_whl
            fi
        elif is_centos; then
            . $(dirname "$0")/centos_installer.sh
            sudo yum install wget -y
            if [[ "$machine" == "x86_64" ]]; then
                echo "Installing Miniconda and creating virtual environment..."
                install_conda_x86_64 "$environment_file"
                install_libraries_centos
                pip3 install awsiotsdk
            else
                install_py3_centos
                install_libraries_centos
                pip3 install awsiotsdk
            fi
            echo "Installing TensorFlow..."
            check_py_version_for_tf
            pip3 install $tf_lite_link"tflite_runtime-"$tf_version"-cp"$tf_compiled_py_version"-cp"$tf_compiled_py_version"m-"$target_platform_whl
        fi
    fi
    ;;
"Darwin")
    . $(dirname "$0")/darwin_installer.sh
    install_libraries_darwin
    if check_tf "$machine"; then
        echo "Skipping TensorFlow installation as it already exists."
    else
        echo "Installing Miniconda and creating virtual environment..."
        install_conda_darwin "$environment_file"
        echo "Installing TensorFlow..."
        check_macOS_version_for_tf
        check_py_version_for_tf
        pip3 install $tf_lite_link"tflite_runtime-"$tf_version"-cp"$tf_compiled_py_version"-cp"$tf_compiled_py_version"m-"$macOS_tf_whl
    fi
    ;;
"Windows")
    . $(dirname "$0")/windows_installer.sh
    echo "Install like Windows..."
    echo "Curling the python.exe file"
    echo "Installing python without UI command. Also include pip"
    echo "Use it to install pip libraries."
    echo "OR"
    echo "install miniconda on windows"
    ;;
esac
