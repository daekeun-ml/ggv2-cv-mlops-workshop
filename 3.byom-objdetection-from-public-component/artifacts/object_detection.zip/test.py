# # Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# # SPDX-License-Identifier: MIT-0
# import sys
# import datetime
# import time

# while True:
    
#     message = f"Hello, {sys.argv[1]}! Current time: {str(datetime.datetime.now())}."
    
#     # Print the message to stdout.
#     print(message)
    
#     # Append the message to the log file.
#     with open('/tmp/Greengrass_HelloWorld.log', 'a') as f:
#         print(message, file=f)
        
#     time.sleep(1)

# # Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# # SPDX-License-Identifier: MIT-0
# import time
# import datetime
# import json
# import awsiot.greengrasscoreipc
# from awsiot.greengrasscoreipc.model import (
#     PublishToTopicRequest,
#     PublishMessage,
#     JsonMessage
# )
# from dummy_sensor import DummySensor


# TIMEOUT = 10
# publish_rate = 1.0

# ipc_client = awsiot.greengrasscoreipc.connect()

# sensor = DummySensor()

# topic = "my/topic"





TIMEOUT = 10

import os
import json
import numpy as np
import glob
import time
from datetime import datetime
from random import randint
from io import BytesIO
from PIL import Image

# import awsiot.greengrasscoreipc
# from awsiot.greengrasscoreipc.model import (
#     PublishToTopicRequest,
#     PublishMessage,
#     JsonMessage
# )
# from awsiot.eventstreamrpc import Connection, LifecycleHandler, MessageAmendment
# import awsiot.greengrasscoreipc.client as client

def softmax(x):
    x_exp = np.exp(x - np.max(x))
    f_x = x_exp / np.sum(x_exp)
    return f_x

import cv2
def prepare_img(img_filepath, img_size=416, verbose=0):
    # Prepare image
    #img = Image.open(img_filepath)
    #img = img.resize((img_size, img_size))
    #img = np.asarray(img).astype('float32')
    
    original_image = cv2.imread(img_filepath)
    original_image = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)
    img = cv2.resize(original_image, (img_size, img_size))
    #image_data = image_data / 255.
    #images_data = np.asarray([image_data]).astype(np.float32)

    img = np.asarray(img).astype('float32')
    img /= 255.0
    #mean = np.array([0.485, 0.456, 0.406])
    #std = np.array([0.229, 0.224, 0.225])
    #img = (img - mean) / std
    #img = np.transpose(img, (2,0,1))
    img  = np.expand_dims(img, axis=0)
    #if verbose == 1:
    #    print(img.shape)

    return img
    
    
def predict(image_data, label_map, verbose=0):
    r"""
    Predict image with DLR.
    :param image_data: numpy array of the image_data
    :label_map: class mapping dictionary
    """
    try:
        model_output = dlr_model.run(image_data)
        probs = softmax(model_output[0][0])
        pred_cls_idx = np.argmax(model_output)
        pred_score = np.max(probs)
        pred_cls_str = label_map[str(pred_cls_idx)].strip()
        
        sort_classes_by_probs = np.argsort(probs)[::-1]
        max_no_of_results = 3
        for i in sort_classes_by_probs[:max_no_of_results]:
            print("[ Class: {}, Score: {} ]".format(label_map[str(i)], probs[i]))

        message = '{"class_id":"' + str(pred_cls_idx) + '"' + ',"class":"' + pred_cls_str + '"' + ',"score":"' + str(pred_score) +'"}'

        payload = {
             "message": message,
             "timestamp": datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        }
        
        if verbose == 1:        
            print(json.dumps(payload, sort_keys=True, indent=4))
        
        return payload

    except Exception as e:
        print("Exception occurred during prediction: %s", e)
        
def nms(boxes, probs, threshold):
  """Non-Maximum supression.
  Args:
    boxes: array of [cx, cy, w, h] (center format)
    probs: array of probabilities
    threshold: two boxes are considered overlapping if their IOU is largher than
        this threshold
    form: 'center' or 'diagonal'
  Returns:
    keep: array of True or False.
  """
 
  order = probs.argsort()[::-1]
  keep = [True]*len(order)
 
  for i in range(len(order)-1):
    ovps = batch_iou(boxes[order[i+1:]], boxes[order[i]])
    for j, ov in enumerate(ovps):
      if ov > threshold:
        keep[order[j+i+1]] = False
  return keep


출처: https://dyndy.tistory.com/275 [DY N DY]


# topic = "my/topic"
model_path = 'model'
test_path = 'sample_images'
# #log_filepath = '/tmp/Greengrass_img.log'
# label_file = 'imagenet1000_clsidx_to_labels.txt'
# label_map = get_label_map_imagenet(label_file)
img_filelist = glob.glob(f"{test_path}/*.jpg")
print(img_filelist)


# Test model on random input data.
#input_shape = input_details[0]['shape']
#input_data = np.array(np.random.random_sample(input_shape), dtype=np.float32)
#input_data = np.array(np.random.randint(0,1000, size=input_shape), dtype=np.float32)

idx = 0
img_filepath = img_filelist[idx]
img = prepare_img(img_filepath)

import tensorflow as tf
    # interpreter = tflite.Interpreter(
    #     model_path=os.path.join(config_utils.MODEL_DIR, "model.tflite")
    # )
interpreter = tf.lite.Interpreter(model_path="../model/yolov4-416.tflite")
interpreter.allocate_tensors() # initialize tensors
print('done')

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

#print(input_details)
#print(output_details)
def filter_boxes(bboxes, pred_classes, score_threshold = 0.5):
    class_boxes = []
    class_ids = []
    for i, box in enumerate(bboxes):
        if pred_classes[i][1] >= score_threshold:
            x1 = (box[0] - box[2]/2)/416
            y1 = (box[1] - box[3]/2)/416
            x2 = (box[0] + box[2]/2)/416
            y2 = (box[1] + box[3]/2)/416
            class_boxes.append([x1,y1,x2,y2]) 
            class_ids.append(pred_classes[i])

    return np.array(class_boxes), class_ids


# Test model on random input data.
input_shape = input_details[0]['shape']
print(input_shape) # 1x300x300x3
print(img.shape)
# #input_data = np.array(np.random.random_sample(input_shape), dtype=np.float32)
# input_data = np.array(np.random.randint(0,1000, size=input_shape), dtype=np.float32)
# #image_data = np.expand_dims(image_data, axis=0).astype(np.uint8)

# 입력 데이터 전달
interpreter.set_tensor(input_details[0]["index"], img)
interpreter.invoke()
# boxes = interpreter.get_tensor(output_details[0]["index"])[0]
# classes = interpreter.get_tensor(output_details[1]["index"])[0]
#print(len(output_details))
pred = [interpreter.get_tensor(output_details[i]['index']) for i in range(len(output_details))]

bboxes = np.array([tuple(x) for x in pred[0][0]])
pred_classes = []
for c in pred[1][0]:
    pred_class = (int(np.argmax(c)), float(np.max(c)))
    pred_classes.append(pred_class)

class_boxes, class_ids = filter_boxes(bboxes, pred_classes)

print(class_boxes)
print(class_ids)
#scores = interpreter.get_tensor(output_details[2]["index"])[0]
#print(boxes)

#print(classes)
#print(scores)

# predicted = []

# while True:
#     # Prepare image
#     idx = randint(0, len(img_filelist)-1)
#     idx = 2
#     img_filepath = img_filelist[idx]
#     img = prepare_img(img_filepath)
    
#     # Predict
#     payload = predict(img, label_map, verbose=1)

#     # Append the message to the log file.
#     #with open(log_filepath, 'a') as f:
#     #    print(payload, file=f)

#     # send_message(payload, topic)
    
#     time.sleep(2)
